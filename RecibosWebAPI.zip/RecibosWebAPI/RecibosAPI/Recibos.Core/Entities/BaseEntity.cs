﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Recibos.Core.Entities
{
    public class BaseEntity
    {
        public int Id { get; set; }
    }
}
