﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Recibos.Core.DTOs
{
    public class CurrencyDto
    {
        public int Id { get; set; }
        public string Acronym { get; set; }
    }
}
